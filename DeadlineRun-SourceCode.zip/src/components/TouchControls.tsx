import React from 'react';
import { ArrowUp, BookOpen } from 'lucide-react';

interface TouchControlsProps {
  onJump: () => void;
  onThrow: () => void;
  isBossStage: boolean;
}

export const TouchControls: React.FC<TouchControlsProps> = ({
  onJump,
  onThrow,
  isBossStage,
}) => {
  return (
    <div className="absolute bottom-4 left-4 right-4 flex items-center justify-between pointer-events-none z-20">
      {/* Left side: Boss weapon button if in boss fight */}
      <div className="flex items-center gap-3">
        {isBossStage && (
          <button
            onClick={onThrow}
            className="pointer-events-auto flex items-center gap-2 px-5 py-3.5 bg-gradient-to-r from-rose-600 to-amber-600 active:scale-95 text-white font-bold rounded-2xl shadow-xl border border-rose-400/40 cursor-pointer select-none transition hover:brightness-110 font-['Fredoka']"
          >
            <BookOpen className="w-5 h-5 text-amber-200" />
            <div className="text-left">
              <div className="text-sm leading-tight">LEMPAR SKRIPSI</div>
              <div className="text-[10px] text-amber-200 font-normal">Tombol X</div>
            </div>
          </button>
        )}
      </div>

      {/* Right side: Jump button (always available) */}
      <div className="ml-auto">
        <button
          onClick={onJump}
          className="pointer-events-auto flex items-center gap-3 px-6 py-4 bg-gradient-to-r from-sky-500 to-blue-600 active:scale-95 text-white font-bold rounded-2xl shadow-2xl border border-sky-300/40 cursor-pointer select-none transition hover:brightness-110 font-['Fredoka']"
        >
          <div className="text-right">
            <div className="text-base leading-tight">LOMPAT</div>
            <div className="text-[11px] text-sky-100 font-normal">SPACE</div>
          </div>
          <div className="w-9 h-9 rounded-xl bg-white/20 flex items-center justify-center">
            <ArrowUp className="w-5 h-5 text-white" />
          </div>
        </button>
      </div>
    </div>
  );
};
