import React from 'react';
import { Play, Sparkles, GraduationCap, ShieldAlert, Zap } from 'lucide-react';

interface StartMenuProps {
  onStart: () => void;
}

export const StartMenu: React.FC<StartMenuProps> = ({ onStart }) => {
  return (
    <div className="absolute inset-0 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4 z-30 overflow-y-auto">
      <div className="max-w-xl w-full bg-slate-900 border border-slate-700/80 rounded-3xl p-6 sm:p-8 shadow-2xl text-center flex flex-col gap-5 my-auto">
        {/* Header Title */}
        <div className="flex flex-col items-center gap-1.5">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-sky-500/20 text-sky-300 border border-sky-500/30 text-xs font-semibold">
            <GraduationCap className="w-4 h-4" />
            Game 2D Endless Runner Kehidupan Mahasiswi
          </div>

          <h1 className="text-4xl sm:text-5xl font-extrabold tracking-tight text-white font-['Fredoka'] drop-shadow-md">
            DEADLINE <span className="text-transparent bg-clip-text bg-gradient-to-r from-amber-400 via-rose-400 to-sky-400">RUN</span>
          </h1>

          <p className="text-sm text-slate-300 max-w-md mx-auto">
            Bantu mahasiswi berlari melewati rintangan kuliah, naik level hingga <span className="text-amber-300 font-semibold">Level Final</span>, dan taklukkan <span className="text-amber-300 font-semibold">Sidang Skripsi</span>!
          </p>
        </div>

        {/* Level Progression Guide */}
        <div className="bg-slate-950/70 rounded-2xl p-3.5 border border-slate-800 text-left">
          <div className="flex items-center gap-1.5 text-xs font-bold text-sky-400 mb-2 font-['Fredoka']">
            <Zap className="w-3.5 h-3.5" />
            PROGRESI TINGKAT KESULITAN LEVEL
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-[11px]">
            <div className="bg-slate-900/80 p-2 rounded-xl border border-slate-800">
              <div className="font-bold text-emerald-400">LEVEL 1</div>
              <div className="text-slate-400">Skor 0–100</div>
              <div className="text-slate-300 mt-0.5">Santai & aman</div>
            </div>
            <div className="bg-slate-900/80 p-2 rounded-xl border border-slate-800">
              <div className="font-bold text-sky-400">LEVEL 2</div>
              <div className="text-slate-400">Skor 101–250</div>
              <div className="text-slate-300 mt-0.5">Mulai sibuk</div>
            </div>
            <div className="bg-slate-900/80 p-2 rounded-xl border border-slate-800">
              <div className="font-bold text-amber-400">LEVEL 3 & 4</div>
              <div className="text-slate-400">Skor 251–700</div>
              <div className="text-slate-300 mt-0.5">Deadline cepat</div>
            </div>
            <div className="bg-slate-900/80 p-2 rounded-xl border border-rose-900/50">
              <div className="font-bold text-rose-400">LEVEL FINAL</div>
              <div className="text-slate-400">Skor 701+</div>
              <div className="text-rose-200 mt-0.5">Sidang Skripsi!</div>
            </div>
          </div>
        </div>

        {/* Quick Guide Grid: Items & Obstacles */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-left">
          {/* Collectibles */}
          <div className="bg-slate-800/80 rounded-2xl p-3.5 border border-slate-700/60">
            <div className="flex items-center gap-1.5 text-xs font-bold text-emerald-400 mb-2 font-['Fredoka']">
              <Sparkles className="w-3.5 h-3.5" />
              ITEM POSITIF
            </div>
            <ul className="text-xs space-y-1.5 text-slate-300">
              <li className="flex items-center justify-between">
                <span>📚 Tugas Selesai</span>
                <span className="font-bold text-emerald-400">+10 Score</span>
              </li>
              <li className="flex items-center justify-between">
                <span>💻 Slide Presentasi</span>
                <span className="font-bold text-emerald-400">+10 Score</span>
              </li>
              <li className="flex items-center justify-between">
                <span>📝 Revisi ACC</span>
                <span className="font-bold text-emerald-400">+15 Score</span>
              </li>
              <li className="flex items-center justify-between">
                <span>⭐ Bintang IPK 4.0</span>
                <span className="font-bold text-amber-400">+25 Bonus</span>
              </li>
            </ul>
          </div>

          {/* Obstacles */}
          <div className="bg-slate-800/80 rounded-2xl p-3.5 border border-slate-700/60">
            <div className="flex items-center gap-1.5 text-xs font-bold text-rose-400 mb-2 font-['Fredoka']">
              <ShieldAlert className="w-3.5 h-3.5" />
              HINDARI RINTANGAN (-1 NYAWA)
            </div>
            <ul className="text-xs space-y-1.5 text-slate-300">
              <li className="flex items-center justify-between">
                <span>🎮 Mabar Online</span>
                <span className="text-rose-400 font-medium">“Lupa Waktu”</span>
              </li>
              <li className="flex items-center justify-between">
                <span>🛌 Kasur Empuk</span>
                <span className="text-rose-400 font-medium">“Mager!”</span>
              </li>
              <li className="flex items-center justify-between">
                <span>📱 Scroll TikTok</span>
                <span className="text-rose-400 font-medium">“Fokus Pecah!”</span>
              </li>
              <li className="flex items-center justify-between">
                <span>☕ Nongkrong Subuh</span>
                <span className="text-rose-400 font-medium">“Kesiangan!”</span>
              </li>
            </ul>
          </div>
        </div>

        {/* Controls Info Banner */}
        <div className="bg-slate-950/60 rounded-2xl px-4 py-3 border border-slate-800 flex items-center justify-around text-xs text-slate-300">
          <div className="flex items-center gap-2">
            <kbd className="px-2 py-1 bg-slate-800 rounded border border-slate-700 text-white font-mono font-bold">SPACE</kbd>
            <span>Lompat</span>
          </div>
          <div className="h-4 w-px bg-slate-700" />
          <div className="flex items-center gap-2">
            <kbd className="px-2 py-1 bg-slate-800 rounded border border-slate-700 text-white font-mono font-bold">X</kbd>
            <span>Lempar Skripsi (Boss)</span>
          </div>
          <div className="h-4 w-px bg-slate-700" />
          <div className="flex items-center gap-1.5 text-amber-300 font-medium">
            <span>Nyawa:</span>
            <span>★ ★ ★</span>
          </div>
        </div>

        {/* Action Button */}
        <div className="pt-1">
          <button
            onClick={onStart}
            className="w-full py-4 px-6 bg-gradient-to-r from-emerald-500 via-teal-500 to-sky-600 hover:from-emerald-400 hover:to-sky-500 active:scale-98 text-white font-bold text-lg rounded-2xl shadow-xl shadow-emerald-500/20 flex items-center justify-center gap-2 transition cursor-pointer font-['Fredoka'] tracking-wide"
          >
            <Play className="w-5 h-5 fill-white" />
            MULAI
          </button>
        </div>
      </div>
    </div>
  );
};
