/**
 * Copyright 2018 Google Inc. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *     http://www.apache.org/licenses/LICENSE-2.0
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

// If the loader is already loaded, just stop.
if (!self.define) {
  let registry = {};

  // Used for `eval` and `importScripts` where we can't get script URL by other means.
  // In both cases, it's safe to use a global var because those functions are synchronous.
  let nextDefineUri;

  const singleRequire = (uri, parentUri) => {
    uri = new URL(uri + ".js", parentUri).href;
    return registry[uri] || (
      
        new Promise(resolve => {
          if ("document" in self) {
            const script = document.createElement("script");
            script.src = uri;
            script.onload = resolve;
            document.head.appendChild(script);
          } else {
            nextDefineUri = uri;
            importScripts(uri);
            resolve();
          }
        })
      
      .then(() => {
        let promise = registry[uri];
        if (!promise) {
          throw new Error(`Module ${uri} didn’t register its module`);
        }
        return promise;
      })
    );
  };

  self.define = (depsNames, factory) => {
    const uri = nextDefineUri || ("document" in self ? document.currentScript.src : "") || location.href;
    if (registry[uri]) {
      // Module is already loading or loaded.
      return;
    }
    let exports = {};
    const require = depUri => singleRequire(depUri, uri);
    const specialDeps = {
      module: { uri },
      exports,
      require
    };
    registry[uri] = Promise.all(depsNames.map(
      depName => specialDeps[depName] || require(depName)
    )).then(deps => {
      factory(...deps);
      return exports;
    });
  };
}
define(['./workbox-afac4cd2'], (function (workbox) { 'use strict';

  self.skipWaiting();
  workbox.clientsClaim();
  /**
   * The precacheAndRoute() method efficiently caches and responds to
   * requests for URLs in the manifest.
   * See https://goo.gl/S9QRab
   */
  workbox.precacheAndRoute([{
    "url": "registerSW.js",
    "revision": "1872c500de691dce40960bb85481de07"
  }, {
    "url": "pwa-maskable-512x512.png",
    "revision": "de21eb19b200e4bfeb93a55272c286f8"
  }, {
    "url": "pwa-512x512.png",
    "revision": "1b3d43243c8587ea3e4c9bbe69fc1b50"
  }, {
    "url": "pwa-192x192.png",
    "revision": "0f2ddbf9922e948a15b9baebe6e9a95c"
  }, {
    "url": "logo-mbd.png",
    "revision": "1be3989cdf0d4ccebfd03dcea57ad426"
  }, {
    "url": "logo-mbd-istts.svg",
    "revision": "912e43afed8de002663b440a6403c7d7"
  }, {
    "url": "logo-mbd-circle.png",
    "revision": "1be3989cdf0d4ccebfd03dcea57ad426"
  }, {
    "url": "logo-istts.svg",
    "revision": "897144b5c55b9e5f56ccabf950f87417"
  }, {
    "url": "logo-istts.png",
    "revision": "54355b6d9397c4b1ecf1751c5e6dbf34"
  }, {
    "url": "logo-istts-full.png",
    "revision": "54355b6d9397c4b1ecf1751c5e6dbf34"
  }, {
    "url": "logo-istts-circle.png",
    "revision": "38f61b38df3af24acc93856aeeed622b"
  }, {
    "url": "index.html",
    "revision": "06856985370efbf9464541d665df82a2"
  }, {
    "url": "favicon.ico",
    "revision": "a7e6a98004cc6d9e5e8b03761c5855b3"
  }, {
    "url": "apple-touch-icon.png",
    "revision": "43ac729987fe98e33d70a3d04f9fb64d"
  }, {
    "url": "assets/index-BrsKEROz.css",
    "revision": null
  }, {
    "url": "assets/index-BhhoLCfY.js",
    "revision": null
  }, {
    "url": "apple-touch-icon.png",
    "revision": "43ac729987fe98e33d70a3d04f9fb64d"
  }, {
    "url": "favicon.ico",
    "revision": "a7e6a98004cc6d9e5e8b03761c5855b3"
  }, {
    "url": "logo-istts-full.png",
    "revision": "54355b6d9397c4b1ecf1751c5e6dbf34"
  }, {
    "url": "logo-mbd.png",
    "revision": "1be3989cdf0d4ccebfd03dcea57ad426"
  }, {
    "url": "pwa-192x192.png",
    "revision": "0f2ddbf9922e948a15b9baebe6e9a95c"
  }, {
    "url": "pwa-512x512.png",
    "revision": "1b3d43243c8587ea3e4c9bbe69fc1b50"
  }, {
    "url": "pwa-maskable-512x512.png",
    "revision": "de21eb19b200e4bfeb93a55272c286f8"
  }, {
    "url": "manifest.webmanifest",
    "revision": "e8c636a34226bb898b06dd1c0cc04044"
  }], {});
  workbox.cleanupOutdatedCaches();
  workbox.registerRoute(new workbox.NavigationRoute(workbox.createHandlerBoundToURL("index.html")));
  workbox.registerRoute(/^https:\/\/fonts\.googleapis\.com\/.*/i, new workbox.CacheFirst({
    "cacheName": "google-fonts-cache",
    plugins: [new workbox.ExpirationPlugin({
      maxEntries: 10,
      maxAgeSeconds: 31536000
    }), new workbox.CacheableResponsePlugin({
      statuses: [0, 200]
    })]
  }), 'GET');
  workbox.registerRoute(/^https:\/\/fonts\.gstatic\.com\/.*/i, new workbox.CacheFirst({
    "cacheName": "gstatic-fonts-cache",
    plugins: [new workbox.ExpirationPlugin({
      maxEntries: 10,
      maxAgeSeconds: 31536000
    }), new workbox.CacheableResponsePlugin({
      statuses: [0, 200]
    })]
  }), 'GET');

}));
